﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace FinGoals
{
    public class CGoalList
    {
        private List<CGoal> goals;

        private JsonSerializerOptions jsonOptions = new JsonSerializerOptions()
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        public CGoalList()
        {
            goals = new List<CGoal>();
        }

        public void Add(CGoal goal)
        {
            goals.Add(goal);
        }

        public void RemoveAt(int index)
        {
            if (index >= 0 && index < goals.Count)
            {
                goals.RemoveAt(index);
            }
        }

        public int getCount()
        {
            return goals.Count;
        }

        public CGoal getGoal(int index)
        {
            return goals[index];
        }

        public void Save(string path)
        {
            List<string> parts = new List<string>();
            for (int i = 0; i < goals.Count; i++)
            {
                parts.Add(JsonSerializer.Serialize(goals[i], goals[i].GetType(), jsonOptions));
            }
            File.WriteAllText(path, "[" + string.Join(",", parts) + "]");
        }

        public void Load(string path)
        {
            goals.Clear();
            JsonDocument doc = JsonDocument.Parse(File.ReadAllText(path));
            foreach (JsonElement el in doc.RootElement.EnumerateArray())
            {
                string name = el.GetProperty("name").GetString();
                double target = el.GetProperty("targetAmount").GetDouble();
                double current = el.GetProperty("currentAmount").GetDouble();
                JsonElement dl;
                string dlText = "";
                if (el.TryGetProperty("deadline", out dl))
                {
                    dlText = dl.GetString();
                }
                if (dlText != null && dlText != "")
                {
                    DateTime deadline = DateTime.Parse(dlText);
                    goals.Add(new CDeadlineGoal(name, target, current, deadline));
                }
                else
                {
                    goals.Add(new CGoal(name, target, current));
                }
            }
        }
    }
}
