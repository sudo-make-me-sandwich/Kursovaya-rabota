﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace FinGoals
{
    public partial class MainWindow : Window
    {
        private CGoalList list;
        private string filePath;

        public MainWindow()
        {
            InitializeComponent();
            list = new CGoalList();
            filePath = Path.GetDirectoryName(
                Process.GetCurrentProcess().MainModule.FileName) + "\\goals.json";
            if (File.Exists(filePath))
            {
                try
                {
                    list.Load(filePath);
                    SetStatus("Цели загружены из файла goals.json: " + list.getCount() + ".");
                }
                catch (Exception ex)
                {
                    SetStatus("Не удалось прочитать goals.json: " + ex.Message);
                }
            }
            else
            {
                list.Add(new CDeadlineGoal("Отпуск", 120000, 70000, DateTime.Today.AddDays(20)));
                list.Add(new CDeadlineGoal("Автомобиль", 1500000, 450000, DateTime.Today.AddDays(240)));
                list.Add(new CGoal("Квартира", 5000000, 1200000));
                SetStatus("Файл goals.json не найден, созданы демонстрационные цели.");
            }
            RefreshView();
        }

        private List<CGoal> BuildView()
        {
            List<CGoal> view = new List<CGoal>();
            for (int i = 0; i < list.getCount(); i++)
            {
                view.Add(list.getGoal(i));
            }
            if (cbCloseFilter.IsChecked == true)
            {
                int days = ParseInt(tbCloseDays.Text, 30);
                List<CGoal> close = new List<CGoal>();
                foreach (CGoal goal in view)
                {
                    CDeadlineGoal dg = goal as CDeadlineGoal;
                    if (dg != null && dg.IsClose(days))
                    {
                        close.Add(dg);
                    }
                }
                view = close;
            }
            if (cbSort.SelectedIndex == 1)
            {
                view.Sort((a, b) => b.ProgressPercent.CompareTo(a.ProgressPercent));
            }
            if (cbSort.SelectedIndex == 2)
            {
                view.Sort((a, b) => CompareDeadlines(a, b));
            }
            return view;
        }

        private int CompareDeadlines(CGoal a, CGoal b)
        {
            CDeadlineGoal da = a as CDeadlineGoal;
            CDeadlineGoal db = b as CDeadlineGoal;
            if (da == null && db == null)
            {
                return 0;
            }
            if (da == null)
            {
                return 1;
            }
            if (db == null)
            {
                return -1;
            }
            return da.Deadline.CompareTo(db.Deadline);
        }

        private void RefreshView()
        {
            if (list == null)
            {
                return;
            }
            goalsListBox.Items.Clear();
            List<CGoal> view = BuildView();
            for (int i = 0; i < view.Count; i++)
            {
                goalsListBox.Items.Add(view[i]);
            }
            UpdateInfo();
        }

        private void UpdateInfo()
        {
            CGoal goal = goalsListBox.SelectedItem as CGoal;
            if (goal == null)
            {
                tbGoalInfo.Text = "Цель не выбрана.";
                btnDelete.IsEnabled = false;
                btnUpdate.IsEnabled = false;
                return;
            }
            btnDelete.IsEnabled = true;
            btnUpdate.IsEnabled = true;
            string info = "Название: " + goal.Name + "\n"
                        + "Накоплено: " + goal.AmountText + "\n"
                        + "Прогресс: " + (int)goal.ProgressPercent + "%";
            CDeadlineGoal dg = goal as CDeadlineGoal;
            if (dg != null)
            {
                info += "\nКрайний срок: " + dg.DeadlineText + " (осталось " + dg.DaysLeft + " дн.)";
            }
            else
            {
                info += "\nБез крайнего срока";
            }
            tbGoalInfo.Text = info;
        }

        private void goalsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateInfo();
        }

        private void cbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshView();
        }

        private void cbCloseFilter_Changed(object sender, RoutedEventArgs e)
        {
            RefreshView();
        }

        private void tbCloseDays_Changed(object sender, TextChangedEventArgs e)
        {
            RefreshView();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddGoalWindow dlg = new AddGoalWindow();
            dlg.Owner = this;
            if (dlg.ShowDialog() == true)
            {
                list.Add(dlg.CreatedGoal);
                SetStatus("Добавлена цель «" + dlg.CreatedGoal.Name + "».");
                RefreshView();
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            CGoal goal = goalsListBox.SelectedItem as CGoal;
            if (goal == null)
            {
                return;
            }
            for (int i = 0; i < list.getCount(); i++)
            {
                if (list.getGoal(i) == goal)
                {
                    list.RemoveAt(i);
                    break;
                }
            }
            SetStatus("Цель «" + goal.Name + "» удалена.");
            RefreshView();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            CGoal goal = goalsListBox.SelectedItem as CGoal;
            if (goal == null)
            {
                return;
            }
            goal.SetCurrent(ParseDouble(tbNewCurrent.Text, goal.CurrentAmount));
            SetStatus("Прогресс цели «" + goal.Name + "» обновлён.");
            RefreshView();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.FileName = "goals";
            dlg.DefaultExt = ".json";
            dlg.Filter = "JSON documents (.json)|*.json";
            if (dlg.ShowDialog() == true)
            {
                try
                {
                    list.Save(dlg.FileName);
                    filePath = dlg.FileName;
                    SetStatus("Цели сохранены в файл.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось сохранить файл: " + ex.Message,
                                    "Сохранение", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.FileName = "goals";
            dlg.DefaultExt = ".json";
            dlg.Filter = "JSON documents (.json)|*.json";
            if (dlg.ShowDialog() == true)
            {
                try
                {
                    list.Load(dlg.FileName);
                    filePath = dlg.FileName;
                    SetStatus("Цели загружены: " + list.getCount() + ".");
                    RefreshView();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Не удалось загрузить файл: " + ex.Message,
                                    "Загрузка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private int ParseInt(string text, int def)
        {
            int v;
            if (int.TryParse(text, out v))
            {
                return v;
            }
            return def;
        }

        private double ParseDouble(string text, double def)
        {
            double v;
            if (double.TryParse(text, out v))
            {
                return v;
            }
            return def;
        }

        private void SetStatus(string text)
        {
            tbStatus.Text = text;
        }
    }
}
