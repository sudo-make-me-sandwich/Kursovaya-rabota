﻿using System;
using System.Text.Json.Serialization;

namespace FinGoals
{
    public class CGoal
    {
        private string name;
        private double targetAmount;
        private double currentAmount;

        public CGoal(string name, double targetAmount, double currentAmount)
        {
            this.name = name;
            this.targetAmount = targetAmount;
            this.currentAmount = currentAmount;
        }

        public string Name
        {
            get { return name; }
        }

        public double TargetAmount
        {
            get { return targetAmount; }
        }

        public double CurrentAmount
        {
            get { return currentAmount; }
        }

        [JsonIgnore]
        public double ProgressPercent
        {
            get
            {
                if (targetAmount <= 0)
                {
                    return 0;
                }
                double p = currentAmount / targetAmount * 100;
                if (p < 0)
                {
                    p = 0;
                }
                if (p > 100)
                {
                    p = 100;
                }
                return p;
            }
        }

        [JsonIgnore]
        public virtual string StatusText
        {
            get { return "Достигнуто " + (int)ProgressPercent + "%"; }
        }

        [JsonIgnore]
        public string AmountText
        {
            get { return currentAmount.ToString("F0") + " из " + targetAmount.ToString("F0"); }
        }

        public void SetCurrent(double value)
        {
            if (value < 0)
            {
                value = 0;
            }
            currentAmount = value;
        }

        public void AddMoney(double value)
        {
            if (value > 0)
            {
                currentAmount += value;
            }
        }
    }
}
