﻿using System;
using System.Text.Json.Serialization;

namespace FinGoals
{
    public class CDeadlineGoal : CGoal
    {
        private DateTime deadline;

        public CDeadlineGoal(string name, double targetAmount, double currentAmount, DateTime deadline)
            : base(name, targetAmount, currentAmount)
        {
            this.deadline = deadline;
        }

        public DateTime Deadline
        {
            get { return deadline; }
        }

        [JsonIgnore]
        public int DaysLeft
        {
            get { return (int)(deadline.Date - DateTime.Today).TotalDays; }
        }

        public bool IsClose(int days)
        {
            return DaysLeft <= days;
        }

        [JsonIgnore]
        public string DeadlineText
        {
            get { return deadline.ToShortDateString(); }
        }

        public override string StatusText
        {
            get
            {
                if (DaysLeft < 0)
                {
                    return base.StatusText + ", дедлайн просрочен";
                }
                return base.StatusText + ", осталось " + DaysLeft + " дн.";
            }
        }
    }
}
