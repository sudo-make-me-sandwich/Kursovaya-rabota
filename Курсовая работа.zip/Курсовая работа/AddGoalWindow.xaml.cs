﻿using System;
using System.Windows;

namespace FinGoals
{
    public partial class AddGoalWindow : Window
    {
        public AddGoalWindow()
        {
            InitializeComponent();
            dpDeadline.SelectedDate = DateTime.Today.AddMonths(3);
        }

        public CGoal CreatedGoal { get; private set; }

        private void cbHasDeadline_Changed(object sender, RoutedEventArgs e)
        {
            dpDeadline.IsEnabled = cbHasDeadline.IsChecked == true;
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            string name = tbName.Text.Trim();
            if (name == "")
            {
                MessageBox.Show("Введите название цели.", "Добавление цели",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            double target;
            if (!double.TryParse(tbTarget.Text, out target) || target <= 0)
            {
                MessageBox.Show("Общая сумма должна быть числом больше нуля.", "Добавление цели",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            double current;
            if (!double.TryParse(tbCurrent.Text, out current) || current < 0)
            {
                MessageBox.Show("Текущие накопления должны быть неотрицательным числом.", "Добавление цели",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (cbHasDeadline.IsChecked == true)
            {
                DateTime dl = dpDeadline.SelectedDate ?? DateTime.Today.AddMonths(3);
                CreatedGoal = new CDeadlineGoal(name, target, current, dl);
            }
            else
            {
                CreatedGoal = new CGoal(name, target, current);
            }
            DialogResult = true;
        }
    }
}
